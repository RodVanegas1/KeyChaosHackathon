# Beany · Bancoagrícola — versión adaptativa

## Objetivo
Demo de llamada preventiva en español con conversación contextual y respuestas breves.

## Cambios clave
- Prompt maestro centrado en contexto vivo y adaptación.
- Evita repetir preguntas, confirmaciones e ideas.
- Responde a lo último que dijo el cliente y utiliza el historial reciente.
- Respuestas breves para una voz telefónica natural.
- Mantiene privacidad: no revela datos internos ni pide saldo/monto ya gestionado por el sistema.
- Transferencia a asesor y cierre natural.
- Panel de analítica separado de datos bancarios privados.

## Ejecutar
```bash
npm install
npm run dev
```

> La instalación puede depender de la conexión disponible para descargar dependencias.


Cambios de voz: respuestas cortas, ritmo 1.06, voz femenina prioritaria y espera a que termine la locución antes de volver a escuchar.
